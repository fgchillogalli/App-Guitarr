 export interface UsuarioI {
    nombre: String;
    celular: String;
    discapacidad: String;
    grado_d: number
}