import { Component, OnInit } from '@angular/core';
import { UsuarioI } from 'src/app/models';

@Component({
  selector: 'app-registrar',
  templateUrl: './registrar.component.html',
  styleUrls: ['./registrar.component.scss'],
})
export class RegistrarComponent implements OnInit {

  usuarios: UsuarioI[]; 
  addNuevo: boolean = false;
  newUsuario: UsuarioI = {
    nombre:'',
    celular: '',
    discapacidad: '',
    grado_d: 0
  }
  editarEnable:boolean = false;

  constructor() {
    this.loadUsuarios();
  }

  ngOnInit() {}

  loadUsuarios(){
    this.usuarios = [
      {
        nombre: 'Fabian ch',
        celular: '0939118244',
        discapacidad:'visual',
        grado_d: 1
      },

      { 
        nombre: 'Juanito Pu',
        celular: '093911834',
        discapacidad:'auditiva',
        grado_d: 2
      },

      {
        nombre: 'Alfonso dr',
        celular: '09391182344',
        discapacidad:'fisica',
        grado_d: 1
      }
    ];
  }

  registrar(){
    this.addNuevo = true;
  }

  cancelar(){
    this.addNuevo = false;
    this.resetForm();
  }

  guardar(){
    if (this.editarEnable == true){
      this.addNuevo = false;
      this.resetForm();

    }else{
      const nuevo : UsuarioI = {
        nombre: this.newUsuario.nombre,
        celular: this.newUsuario.celular,
        discapacidad:this.newUsuario.discapacidad,
        grado_d: this.newUsuario.grado_d
      };
      this.usuarios.push(nuevo);
      this.addNuevo = false;
      this.resetForm();
      alert("Se ha Guardado Con Exito :)")
    }  
  }

  resetForm(){
    this.newUsuario = {
      nombre:'',
      celular: '',
      discapacidad: '',
      grado_d: 0
    }
  }

  editar(usuario: UsuarioI){
    this.editarEnable = true;
    this.addNuevo = true;
    this.newUsuario = usuario;
  }

  eliminar(i : number){
    this.usuarios.splice(i)
  }

}
