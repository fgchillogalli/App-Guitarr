import { Component, OnInit } from '@angular/core';
import { UsuarioI } from 'src/app/models';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  usuarios:UsuarioI[];
  grado: String;

  constructor() { 
    this.loadUsuarios()
  }

  ngOnInit() {}

  loadUsuarios(){
    this.usuarios = [
      {
        nombre: 'Fabian ch',
        celular: '0939118244',
        discapacidad:'visual',
        grado_d: 1
      },

      {
        nombre: 'Juanito Pu',
        celular: '093911834',
        discapacidad:'auditiva',
        grado_d: 2
      },

      {
        nombre: 'Alfonso dr',
        celular: '09391182344',
        discapacidad:'fisica',
        grado_d: 1
      }
    ];
  }

  selctFisica(){
    this.grado = "fisica";
  }

  selctVisual(){
    this.grado = "visual";
  }

  selctAuditiva(){
    this.grado = "auditiva";
  }

}
